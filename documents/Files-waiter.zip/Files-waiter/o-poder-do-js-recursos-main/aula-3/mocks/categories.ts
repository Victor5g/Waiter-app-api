const categories = [
  {
    _id: '6372d595f9ebdda354700c8d',
    name: 'Pizza',
    icon: '🍕',
  },
  {
    _id: '6372d5bff9ebdda354700c90',
    name: 'Bebidas',
    icon: '🍻',
  },
  {
    _id: '6372d5d2f9ebdda354700c92',
    name: 'Burgers',
    icon: '🍔',
  },
  {
    _id: '6372d5dcf9ebdda354700c94',
    name: 'Promoções',
    icon: '🏷',
  },
];